import { Actor } from '../actor/actor';

export interface Credits {
  id: number;
  cast: Actor[];
}
